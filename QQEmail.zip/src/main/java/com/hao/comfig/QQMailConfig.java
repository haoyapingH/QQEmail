package com.hao.comfig;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.xml.ws.ServiceMode;
import java.util.Date;
import java.util.Properties;

/**
 * 邮箱配置类
 *
 * @author 郝好
 * @data Thu Feb 27 23:13:53 CST 2020
 */

public class QQMailConfig {
    //此处填写SMTP服务器
    public static final String MAIL_SMTP_HOST = "smtp.qq.com";
    // 表示SMTP发送邮件，必须进行身份验证
    public static final String MAIL_SMTP_AUTH = "true";
    //端口号，QQ邮箱端口587
    public static final String MAIL_SMTP_PORT = "587";
    // 此处填写，写信人的账号
    public static final String MAIL_USER = "******@qq.com";
    // 此处填写16位STMP口令
    public static final String MAIL_PASSWORD = "*********";


    public static Session getSessionInstance() {
        // 创建Properties 类用于记录邮箱的一些属性
        Properties props = new Properties();
        props.put("mail.smtp.auth", MAIL_SMTP_AUTH);
        props.put("mail.smtp.host", MAIL_SMTP_HOST);
        props.put("mail.smtp.port", MAIL_SMTP_PORT);
        props.put("mail.user", MAIL_USER);
        props.put("mail.password", MAIL_PASSWORD);
        // 构建授权信息，用于进行SMTP进行身份验证
        Authenticator authenticator = new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                // 用户名、密码
                return new PasswordAuthentication(MAIL_USER, MAIL_PASSWORD);
            }
        };
        return Session.getInstance(props, authenticator);


    }

}
