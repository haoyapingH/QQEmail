package com.hao.service.impl;

import com.hao.service.IQQMailService;
import com.hao.comfig.QQMailConfig;

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.MimeMessage.RecipientType;
import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * @author 郝好
 * @data Thu Feb 27 23:13:53 CST 2020
 */

public class QQMailServiceImpl implements IQQMailService {

    /**
     * 以文本方式发送邮箱
     *
     * @param title       邮箱标题
     * @param content     邮箱内容
     * @param targetEmail 收件人
     * @throws AddressException
     * @throws MessagingException
     */
    public void sendTextMail(String title, String content, String targetEmail)
            throws AddressException, MessagingException {
        // 使用环境属性和授权信息，创建邮件会话
        Session mailSession = QQMailConfig.getSessionInstance();
        // 创建邮件消息
        MimeMessage message = new MimeMessage(mailSession);
        // 设置发件人
        InternetAddress form = new InternetAddress(QQMailConfig.MAIL_USER);
        message.setFrom(form);
        // 设置收件人的邮箱
        InternetAddress to = new InternetAddress(targetEmail);
        message.setRecipient(RecipientType.TO, to);
        // 设置邮件标题
        message.setSubject(title);
        // 设置邮件的内容体
        message.setText(content, "utf-8");
        // 最后当然就是发送邮件啦
        Transport.send(message);
        System.out.println("sendTextMail--- success " + " title = " + title);
    }

    /**
     * 以 HTML 方式发送邮箱
     *
     * @param title       邮箱标题
     * @param content     邮箱内容
     * @param targetEmail 收件人
     * @throws AddressException
     * @throws MessagingException
     */
    public void sendHtmlMail(String title, String content, String targetEmail)
            throws AddressException, MessagingException {
        // 使用环境属性和授权信息，创建邮件会话
        Session mailSession = QQMailConfig.getSessionInstance();
        // 创建邮件消息
        MimeMessage message = new MimeMessage(mailSession);
        // 设置收件人的邮箱
        InternetAddress to = new InternetAddress(targetEmail);
        message.setRecipient(RecipientType.TO, to);
        // 设置发件人
        InternetAddress form = new InternetAddress(QQMailConfig.MAIL_USER);
        // 设置邮件消息发送的时间
        message.setSentDate(new Date());
        message.setFrom(form);
        // 设置邮件标题
        message.setSubject(title);
        // MiniMultipart类是一个容器类，包含MimeBodyPart类型的对象
        Multipart mainPart = new MimeMultipart();
        // 创建一个包含HTML内容的MimeBodyPart
        BodyPart html = new MimeBodyPart();
        // 设置HTML内容
        html.setContent(content, "text/html; charset=utf-8");
        mainPart.addBodyPart(html);
        // 将MiniMultipart对象设置为邮件内容
        message.setContent(mainPart);
        // 最后当然就是发送邮件啦
        Transport.send(message);
        System.out.println("sendHtmlMail--- success " + " title = " + title);
    }

    /**
     * 发送邮件 平却 添加附件
     *
     * @param title         标题
     * @param content       邮箱内容
     * @param targetEmail   收件人
     * @param enclosurePath 附件地址
     * @throws AddressException
     * @throws MessagingException
     * @throws IOException
     */
    public void sendHtmlMailAddFile(String title, String content,
                                    String targetEmail, String enclosurePath)
            throws AddressException, MessagingException, IOException {
        // 使用环境属性和授权信息，创建邮件会话
        Session mailSession = QQMailConfig.getSessionInstance();
        // 设置收件人的邮箱
        InternetAddress to = new InternetAddress(targetEmail);
        // 创建邮件消息
        MimeMessage message = new MimeMessage(mailSession);
        message.setRecipient(RecipientType.TO, to);
        // 设置发件人
        InternetAddress form = new InternetAddress(QQMailConfig.MAIL_USER);
        message.setFrom(form);
        // 设置邮件消息发送的时间
        message.setSentDate(new Date());
        // 设置邮件标题
        message.setSubject(title);
        // MiniMultipart类是一个容器类，包含MimeBodyPart类型的对象
        Multipart mainPart = new MimeMultipart();
        // 创建一个包含HTML内容的MimeBodyPart
        BodyPart html = new MimeBodyPart();
        // 设置HTML内容
        html.setContent(content, "text/html; charset=utf-8");
        mainPart.addBodyPart(html);
        //添加邮件
        // 注意这里是MimeBodyPart
        MimeBodyPart part = new MimeBodyPart();
        // 这里放附件的路径
        part.attachFile(enclosurePath);
        //多个附件也是一样的,创建多个MimeBodyPart ,最后放入mainPart 里面
        mainPart.addBodyPart(part);
        // 将MiniMultipart对象设置为邮件内容
        message.setContent(mainPart);
        // 发送邮件
        // 最后当然就是发送邮件啦
        Transport.send(message);
        System.out.println("sendHtmlMailAddFile --- success " + " title = " + title);
    }

    /**
     * 发送邮件 平却 添加附件
     *
     * @param title              标题
     * @param content            邮箱内容
     * @param targetEmail        收件人
     * @param enclosureDirectory 附件 m目录
     * @throws AddressException
     * @throws MessagingException
     * @throws IOException
     */
    public void sendHtmlMailAddFileS(String title, String content,
                                     String targetEmail, String enclosureDirectory)
            throws AddressException, MessagingException, IOException {
        // 使用环境属性和授权信息，创建邮件会话
        Session mailSession = QQMailConfig.getSessionInstance();
        // 设置收件人的邮箱
        InternetAddress to = new InternetAddress(targetEmail);
        // 创建邮件消息
        MimeMessage message = new MimeMessage(mailSession);
        message.setRecipient(RecipientType.TO, to);
        // 设置发件人
        InternetAddress form = new InternetAddress(QQMailConfig.MAIL_USER);
        message.setFrom(form);
        // 设置邮件消息发送的时间
        message.setSentDate(new Date());
        // 设置邮件标题
        message.setSubject(title);
        // MiniMultipart类是一个容器类，包含MimeBodyPart类型的对象
        Multipart mainPart = new MimeMultipart();
        // 创建一个包含HTML内容的MimeBodyPart
        BodyPart html = new MimeBodyPart();
        // 设置HTML内容
        html.setContent(content, "text/html; charset=utf-8");
        mainPart.addBodyPart(html);
        //添加邮件
        File file = new File(enclosureDirectory);
        File[] listFiles = file.listFiles();
        for (int i = 0; i < listFiles.length; i++) {
            String temppath = listFiles[i].getPath();
            // 注意这里是MimeBodyPart
            MimeBodyPart part = new MimeBodyPart();
            // 这里放附件的路径
            part.attachFile(temppath);
            //多个附件也是一样的,创建多个MimeBodyPart ,最后放入mainPart 里面
            mainPart.addBodyPart(part);
        }
        // 将MiniMultipart对象设置为邮件内容
        message.setContent(mainPart);
        // 发送邮件
        // 最后当然就是发送邮件啦
        Transport.send(message);
        System.out.println("sendHtmlMailAddFile --- success " + " title = " + title);
    }
}
