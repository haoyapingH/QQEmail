package com.hao.service;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import java.io.IOException;

/**
 * @author 郝好
 * @data Thu Feb 27 23:13:53 CST 2020
 */
public interface IQQMailService {

    public void sendTextMail(String title, String content, String targetEmail)
            throws AddressException, MessagingException;

    public void sendHtmlMail(String title, String content, String targetEmail)
            throws AddressException, MessagingException;

    public void sendHtmlMailAddFile(String title, String content,
                                    String targetEmail, String enclosurePath)
            throws AddressException, MessagingException, IOException;
}
