package com.hao;

import com.hao.service.impl.QQMailServiceImpl;

import javax.mail.MessagingException;
import java.io.IOException;

public class TestDemo {
    public static void main(String[] args) throws MessagingException, IOException {
        QQMailServiceImpl qqMailService = new QQMailServiceImpl();
        qqMailService.sendTextMail("这是以Text方式发送的邮箱",
                "<h1 style='font-size: 52px ;color: blue'>Be a great Creator</h1>",
                "****.com");
        qqMailService.sendHtmlMail("这是以HTML方式发送的邮箱",
                "<h1 style='font-size: 52px ;color: blue'>Be a great Creator</h1>",
                "****.com");
        qqMailService.sendHtmlMailAddFile("这是以HTML方式发送的邮箱 + 附件 ",
                "<h1 style='font-size: 52px ;color: blue'>带有附件的邮箱---Be a great Creator</h1>",
                "*****.com", "E:\\1.jpg");
    }

}
